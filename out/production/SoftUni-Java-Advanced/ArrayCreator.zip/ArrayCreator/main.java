package ArrayCreator;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        ArrayCreator arrayCreator = new ArrayCreator();
    }
}
