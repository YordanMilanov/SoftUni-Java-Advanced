package RawData_04;

public class Engine {
    private int enginePower;
    private int engineSpeed;

    public Engine(int enginePower, int engineSpeed) {
        this.enginePower = enginePower;
        this.engineSpeed = engineSpeed;
    }

    public int getEnginePower() {
        return enginePower;
    }
}
