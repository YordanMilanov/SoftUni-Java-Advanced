package university;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class University {
    public static List<Student> students;
    public static int capacity;

    public University( int capacity) {
        this.students = new ArrayList<>();
        this.capacity = capacity;
    }

    public List<Student> getStudents() {
        return students;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getStudentCount() {
        return students.size();
    }

    public static String registerStudent (Student student) {
        if (students.contains(student)) {
            return "Student is already in the university";
        }
        else {
            if (students.size() < capacity) {
                students.add(student);
                return "Added student " + student.getFirstName() + " " + student.getLastName();
            } else {
                return "No seats in the university";
            }
        }
    }

    public static String dismissStudent (Student student) {
        if (students.contains(student)) {
            students.remove(student);
            return "";
        } else {
            return "Student not found";
        }
    }

    public Student getStudent (String firstName, String lastName) {
        Student studentToReturn = null;
        for (Student student : students) {
            if (student.getFirstName().equals(firstName) && student.getLastName().equals(lastName)) {
                studentToReturn = student;
            }
        }
        return studentToReturn;
    }

    public static String getStatistics () {
        StringBuilder sb = new StringBuilder();
        for (Student student : students) {
            sb.append(String.format("==Student: First Name = %s, Last Name = %s, Best Subject = %s%n", student.getFirstName(), student.getLastName(), student.getBestSubject()));
        }
        return sb.toString();
    }
}
